#pragma once

int plus(int a, int b);
